import xbmc
import xbmcgui
import xbmcvfs
import shutil
import os

ADDON_ID = "plugin.program.install.arcticfuse2.custom"
SKIN_ID = "skin.arctic.fuse.2"

def notify(title, message, time=3000):
    xbmcgui.Dialog().notification(
        title, message, xbmcgui.NOTIFICATION_INFO, time
    )

def ensure_skin_installed():
    skin_path = xbmcvfs.translatePath(
        f"special://home/addons/{SKIN_ID}"
    )

    if not os.path.exists(skin_path):
        notify("Installation", "Installation du skin Arctic Fuse 2...")
        xbmc.executebuiltin(f"InstallAddon({SKIN_ID})")
        xbmc.sleep(5000)

def apply_settings():
    src = xbmcvfs.translatePath(
        f"special://home/addons/{ADDON_ID}/resources/addon_data/{SKIN_ID}"
    )

    dst = xbmcvfs.translatePath(
        f"special://masterprofile/addon_data/{SKIN_ID}"
    )

    if not os.path.exists(src):
        notify("Erreur", "Settings introuvables")
        return

    os.makedirs(dst, exist_ok=True)
    shutil.copytree(src, dst, dirs_exist_ok=True)

def apply_skin():
    xbmc.executebuiltin(f"Skin.SetSkin({SKIN_ID})")
    xbmc.executebuiltin("ReloadSkin")

def run():
    notify("Arctic Fuse Custom", "Application du pack...")
    ensure_skin_installed()
    apply_settings()
    apply_skin()
    notify("Terminé", "Skin configuré avec succès", 5000)

if __name__ == "__main__":
    run()
